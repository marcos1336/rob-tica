#include <iostream>
using namespace std;

// Função que calcula a área do retângulo
float calcularAreaRetangulo(float base, float altura) {
    return base * altura;
}

int main() {
    float base, altura;

    cout << "Digite a base do retângulo: ";
    cin >> base;

    cout << "Digite a altura do retângulo: ";
    cin >> altura;

    float area = calcularAreaRetangulo(base, altura);

    cout << "A área do retângulo é: " << area << endl;

    return 0;
}