#include <iostream>
using namespace std;

int main() {
    int numero = 42;           // Variável inteira
    int* ponteiro = &numero;   // Ponteiro para int, apontando para a variável 'numero'

    // Exibindo o valor da variável e seu endereço
    cout << "Valor da variável: " << *ponteiro << endl;
    cout << "Endereço da variável: " << ponteiro << endl;

    return 0;
}
