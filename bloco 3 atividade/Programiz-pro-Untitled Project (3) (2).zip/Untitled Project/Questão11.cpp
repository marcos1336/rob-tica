#include <iostream>
using namespace std;

// Função que exibe os elementos de um vetor usando ponteiro
void exibirVetor(int* vetor, int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        cout << "Elemento " << i << ": " << *(vetor + i) << endl;
    }
}

int main() {
    int numeros[5] = {10, 20, 30, 40, 50};

    exibirVetor(numeros, 5); // Passa o vetor como ponteiro

    return 0;
}