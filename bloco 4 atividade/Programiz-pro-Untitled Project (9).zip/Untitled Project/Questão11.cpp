#include <iostream>
#include <string>
using namespace std;

// Função que exibe a situação do aluno com base na nota
void verificarSituacao(string nome, float nota) {
    cout << "Aluno: " << nome << endl;
    cout << "Nota: " << nota << endl;

    if (nota >= 7.0) {
        cout << "Situação: Aprovado" << endl;
    } else {
        cout << "Situação: Reprovado" << endl;
    }
}

int main() {
    string nome;
    float nota;

    cout << "Digite o nome do aluno: ";
    getline(cin, nome);

    cout << "Digite a nota do aluno: ";
    cin >> nota;

    verificarSituacao(nome, nota);

    return 0;
}