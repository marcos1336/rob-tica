#include <iostream>
using namespace std;

// Função que calcula a média de três notas (passadas por valor)
float calcularMedia(float n1, float n2, float n3) {
    return (n1 + n2 + n3) / 3.0;
}

int main() {
    float nota1, nota2, nota3;

    cout << "Digite a primeira nota: ";
    cin >> nota1;

    cout << "Digite a segunda nota: ";
    cin >> nota2;

    cout << "Digite a terceira nota: ";
    cin >> nota3;

    float media = calcularMedia(nota1, nota2, nota3);

    cout << "A média das notas é: " << media << endl;

    return 0;
}